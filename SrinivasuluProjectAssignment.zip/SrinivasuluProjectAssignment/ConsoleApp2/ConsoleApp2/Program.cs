﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Program
    {
        static void input(int[] a)
        {
            Console.WriteLine("Enter the elements of Array:");

            for (int i = 0; i < a.Length; i++)
            {
                a[i] = 0;

            }
        }
        static void output(int[] a)
        {
            int c = 0;
            for (int i = 0; i < a.Length; i++)
            {
                Console.Write(a[i] + "\t");
                c++;
                if (c % 5 == 0)
                    Console.WriteLine();
            }

        }
        static void Main(string[] args)
        {
            int n;
            Console.WriteLine("ENTER THE NOOF ELEMENTS IN THE ARRAY:");
            n = int.Parse(Console.ReadLine());
            int[] a = new int[n];
            int p = int.Parse(Console.ReadLine());
            input(a);
            a[p] = 1;
            output(a);

            while (true)
            {
                Console.WriteLine("Enter the choice: 1:EXIT  8: UP   2: DOWN  4: LEFT 6: RIGHT  ");
                int ch = int.Parse(Console.ReadLine());
                if (ch == 1)
                    break;
                else if (ch == 2)
                {
                    if (p == 20 || p == 21 || p == 22 || p == 23 || p == 24)
                        Console.WriteLine("DOWN OPERATION CANNOT BE PERFORMED!!!");
                    else
                    {
                        p = p + 5;
                        down(a, p);
                    }
                }
                else if (ch == 8)
                {
                    if (p == 0 || p == 1 || p == 2 || p == 3 || p == 4)
                        Console.WriteLine("UP OPERATION CANNOT BE PERFORMED!!!");
                    else
                    {
                        p = p - 5;
                        up(a, p);
                    }
                }
                else if (ch == 4)
                {

                    if (p == 0 || p == 5 || p == 10 || p == 15 || p == 20)
                        Console.WriteLine("LEFT OPERATION CANNOT BE PERFORMED!!!");
                    else
                    {
                        p = p - 1;
                        left(a, p);
                    }
                }
                else if (ch == 6)
                {
                    
                    if (p == 4 || p == 9 || p == 14 || p == 19 || p == 24)
                        Console.WriteLine("RIGHT OPERATION CANNOT BE PERFORMED!!!");
                    else
                    {
                        p = p + 1;
                        right(a, p);
                    }
                }
                else
                    Console.WriteLine("YOU ENTERED WROGN CHOICE!!!  PLEASE ENTER THE CORECT CHOICE");
            }
        }
        static void right(int[] a, int p)
        {
            if (p >= 0 && p < a.Length)
            {
                a[p] = 1;
                a[p - 1] = 0;
                output(a);
                Console.WriteLine("RIGHT OPERTION HAS BEEN PERFORMED");
            }

        }
        static void left(int[] a,int p)
        {
            if (p >= 0 && p < a.Length)
            {
                a[p] = 1;
                a[p + 1] = 0;
                output(a);
                Console.WriteLine("LEFT OPERATION HAS BEEN PERFORMED");
            }
            
        }
        static void up(int[] a, int p)
        {
            if (p >= 0 && p < a.Length)
            {
                a[p] = 1;
                a[p + 5] = 0;
                output(a);
                Console.WriteLine("UP OPERATION HAS BEEN PERFORMED");
            }
        }
        static void down(int[] a, int p)
        {
            
            if (p >= 0 && p < a.Length)
            {
                
                a[p] = 1;
                a[p - 5] = 0;
                output(a);
                Console.WriteLine("DOWN OPERATION HAS BEEN PERFORMED");
            }
            else
                Console.WriteLine("Down operation not possible!!!");
        }
        
    }
}
