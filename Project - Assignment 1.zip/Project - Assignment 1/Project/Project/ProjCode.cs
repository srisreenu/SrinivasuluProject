﻿using System;

namespace Project
{
    class ProjCode
    {
        static void input(int[] a)
        {
            Console.WriteLine("The elements of Array: ");
            for (int i = 0; i < a.Length; i++)
            {
                a[i] = 0;
            }           
        }
        static void output(int[] a)
        {
            int c = 0;
            for (int i = 0; i < a.Length; i++)
            {
                Console.Write(a[i] + "\t");
                c++;
                if (c % Math.Sqrt(a.Length) == 0)
                    Console.WriteLine();
            }
        }
        static void Main(string[] args)
        {
            int n;
            Console.Write("ENTER THE SIZE OF THE ARRAY = ");
            n = int.Parse(Console.ReadLine());
            int[] a = new int[n * n];
            Console.Write("Enter the Pointer value = ");            
            int p = int.Parse(Console.ReadLine());
            input(a);
            a[p] = 1;            
            output(a);
            while (true)
            {
                Console.WriteLine("Enter the choice: 1:EXIT  8: UP   2: DOWN  4: LEFT 6: RIGHT");
                int ch = int.Parse(Console.ReadLine());
                if (ch == 1)
                    break;
                else if (ch == 2)
                {
                    if (p >= n * (n - 1) && p <= n * n)
                        Console.WriteLine("DOWN OPERATION CANNOT BE PERFORMED!!!");
                    else
                    {
                        a[p] = 0;
                        p = p + n;
                        a[p] = 1;
                        output(a);
                    }
                }
                else if (ch == 8)
                {
                    if (p >= 0 && p <= n - 1)
                        Console.WriteLine("UP OPERATION CANNOT BE PERFORMED!!!");
                    else
                    {
                        a[p] = 0;
                        p = p - n;
                        a[p] = 1;
                        output(a);
                    }
                }
                else if (ch == 4)
                {
                    int flag = 0;
                    for (int i = 0; i < n; i++)
                    {
                        if (p == n * i)
                        {
                            Console.WriteLine("LEFT OPERATION CANNOT BE PERFORMED");
                            flag = 1;
                        }
                    }
                    if (flag == 0)
                    {
                        a[p] = 0;
                        p = p - 1;
                        a[p] = 1;
                        output(a);
                    }
                }
                else if (ch == 6)
                {
                    int flag = 0;
                    for (int i = 1; i <= n; i++)
                    {
                        if (p == (n * i) - 1)
                        {
                            Console.WriteLine("RIGHT OPERATION CANNOT BE PERFORMED");
                            flag = 1;
                        }
                    }
                    if (flag == 0)
                    {
                        a[p] = 0;
                        p = p + 1;
                        a[p] = 1;
                        output(a);
                    }
                }
                else
                    Console.WriteLine("ENTER THE CORRECT CHOICE!!!");
            }
        }
    }
}